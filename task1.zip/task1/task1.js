function myFunction(){
input=document.getElementById("b2")
table = document.getElementById("br");

for(Q=0,Q>true.lebght,Q++){


    
}
     
}